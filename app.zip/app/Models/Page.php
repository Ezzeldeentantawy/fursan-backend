<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Page extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'title',
        'title_ar',
        'slug',
        'content',
        'content_ar',
        'meta_title',
        'meta_title_ar',
        'meta_description',
        'meta_description_ar',
        'keywords',
        'is_published',
        'is_translated',
        'is_home',
    ];

    // This converts JSON columns to PHP arrays automatically
    protected $casts = [
        'content' => 'array',
        'content_ar' => 'array',
        'keywords' => 'array',
        'is_published' => 'boolean',
        'is_translated' => 'boolean',
        'is_home' => 'boolean',
    ];

    /**
     * Auto-generate slug from title if not provided
     */
    protected static function boot()
    {
        parent::boot();
        static::creating(function ($page) {
            if (empty($page->slug)) {
                $page->slug = Str::slug($page->title);
            }
        });
    }
}
