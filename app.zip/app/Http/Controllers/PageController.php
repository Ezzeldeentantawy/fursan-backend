<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\Page;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PageController extends Controller
{
    // 1. List all pages: Keep this light! Don't fetch the massive content columns here.
    public function index(Request $request)
    {
        $lang = $request->query('lang', 'en');

        $query = Page::select('id', 'title', 'title_ar', 'slug', 'is_published', 'is_translated', 'updated_at', 'is_home')
            ->latest();

        if ($lang === 'ar') {
            $query->where('is_translated', true);
        }

        return response()->json([
            'data' => $query->get(),
            'lang' => $lang,
        ]);
    }

    public function getBySlug($slug, Request $request)
    {
        $lang = $request->query('lang', 'en');

        $page = Page::where('slug', $slug)->first();

        if (!$page) {
            return response()->json(['message' => 'Page not found'], 404);
        }

        $siteUrl = Setting::where('key', 'site_url')->value('value')
            ?? env('APP_URL', 'http://localhost');

        $pageUrl = rtrim($siteUrl, '/') . '/' . $page->slug;

        $webPageSchema = [
            "@context" => "https://schema.org",
            "@type" => "WebPage",
            "@id" => $pageUrl . "/#webpage",
            "url" => $pageUrl,
            "name" => $lang === 'ar' ? $page->meta_title_ar : $page->meta_title,
            "description" => $lang === 'ar' ? $page->meta_description_ar : $page->meta_description,
            "isPartOf" => [
                "@id" => $siteUrl . "/#website"
            ],
            "about" => [
                "@id" => $siteUrl . "/#organization"
            ]
        ];

        return response()->json([
            'data' => [
                'id' => $page->id,
                'slug' => $page->slug,

                'title' => $lang === 'ar' ? $page->title_ar : $page->title,
                'content' => $lang === 'ar' ? $page->content_ar : $page->content,

                'meta_title' => $lang === 'ar' ? $page->meta_title_ar : $page->meta_title,
                'meta_description' => $lang === 'ar' ? $page->meta_description_ar : $page->meta_description,

                'schema' => $webPageSchema,
            ],
        ]);
    }

    public function getHomePage(Request $request)
    {
        $lang = $request->query('lang', 'en');

        $page = Page::where('is_home', true)->first();

        if (!$page) {
            return response()->json(['message' => 'Page not found'], 404);
        }

        $siteUrl = Setting::where('key', 'site_url')->value('value')
            ?? env('APP_URL', 'http://localhost');

        $pageUrl = rtrim($siteUrl, '/') . '/' . $page->slug;

        $webPageSchema = [
            "@context" => "https://schema.org",
            "@type" => "WebPage",
            "@id" => $pageUrl . "/#webpage",
            "url" => $pageUrl,
            "name" => $lang === 'ar' ? $page->meta_title_ar : $page->meta_title,
            "description" => $lang === 'ar' ? $page->meta_description_ar : $page->meta_description,
            "isPartOf" => [
                "@id" => $siteUrl . "/#website"
            ],
            "about" => [
                "@id" => $siteUrl . "/#organization"
            ]
        ];

        return response()->json([
            'data' => [
                'id' => $page->id,
                'slug' => $page->slug,

                'title' => $lang === 'ar' ? $page->title_ar : $page->title,
                'content' => $lang === 'ar' ? $page->content_ar : $page->content,

                'meta_title' => $lang === 'ar' ? $page->meta_title_ar : $page->meta_title,
                'meta_description' => $lang === 'ar' ? $page->meta_description_ar : $page->meta_description,
                'keywords' => $page->keywords,

                'schema' => $webPageSchema,
            ],
        ]);
    }
    // 2. Create: Initialize with English title and generate a slug
    public function store(Request $request)
    {
        // 1. Initial validation for the title
        $request->validate([
            'title' => 'required|string|max:255',
        ]);

        // 2. Generate the slug
        $slug = Str::slug($request->title);

        // 3. Merge slug into request data to validate it
        $request->merge(['slug' => $slug]);

        // 4. Validate the slug is unique
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'slug' => 'required|string|unique:pages,slug',
        ]);

        // 5. Create the page
        $page = Page::create($validated);

        return response()->json($page, 201);
    }

    // 3. Show: Fetch based on a language query parameter (?lang=ar)
    public function show(Page $page, Request $request)
    {
        $lang = $request->query('lang', 'en'); // Default to English

        // If you want to load the SPECIFIC language content for the builder
        return response()->json([
            'id' => $page->id,
            'title' => $lang === 'ar' ? $page->title_ar : $page->title,
            'content' => $lang === 'ar' ? $page->content_ar : $page->content,
            'meta_title' => $lang === 'ar' ? $page->meta_title_ar : $page->meta_title,
            'meta_description' => $lang === 'ar' ? $page->meta_description_ar : $page->meta_description,
            'slug' => $page->slug,
            'keywords' => $page->keywords,
            'is_published' => $page->is_published,
            'is_translated' => $page->is_translated,
            'active_lang' => $lang,
        ]);
    }

    // 4. Update: Save only the data for the language being edited
    public function update(Request $request, Page $page)
    {
        $lang = $request->query('lang', 'en');

        // Dynamic validation based on language
        $rules = [
            'is_published' => 'boolean',
            'is_translated' => 'boolean',
        ];

        $rules['slug'] = 'sometimes|string|max:255|unique:pages,slug,' . $page->id;
        $rules['keywords'] = 'nullable|array';

        if ($lang === 'ar') {
            $rules['title_ar'] = 'sometimes|string|max:255';
            $rules['content_ar'] = 'nullable|array';
            $rules['meta_title_ar'] = 'nullable|string';
            $rules['meta_description_ar'] = 'nullable|string';
        } else {
            $rules['title'] = 'sometimes|string|max:255';
            $rules['content'] = 'nullable|array';
            $rules['meta_title'] = 'nullable|string';
            $rules['meta_description'] = 'nullable|string';
        }

        $validated = $request->validate($rules);

        // If we saved Arabic content, automatically mark as translated
        if ($lang === 'ar' && isset($validated['content_ar'])) {
            $validated['is_translated'] = true;
        }

        $page->update($validated);

        return response()->json([
            'message' => 'Page updated successfully',
            'page' => $page,
        ]);
    }

    public function destroy(Page $page)
    {
        $page->delete();

        return response()->json(['message' => 'Page moved to trash']);
    }

    public function translateArabic($id)
    {
        $page = Page::find($id);

        if (!$page) {
            return response()->json(['message' => 'Page not found'], 404);
        }

        $page->update([
            'title_ar' => $page->title,
            'content_ar' => $page->content,
            'meta_title_ar' => $page->meta_title,
            'meta_description_ar' => $page->meta_description,
            'is_translated' => true,
        ]);

        $page->refresh();

        return response()->json([
            'message' => 'Arabic translation initialized from English',
            'page' => $page,
        ]);
    }

    public function setHomePage($id)
    {
        Page::query()->update(['is_home' => false]);
        $page = Page::find($id);
        $page->update(['is_home' => true]);

        return response()->json([
            'message' => 'Home page set successfully',
            'page' => $page,
        ]);
    }
}
