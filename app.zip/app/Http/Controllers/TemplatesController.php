<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Template;

class TemplatesController extends Controller
{
    public function index()
    {
        return response()->json(Template::latest()->get());
    }

    // Create a new empty page
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'nullable|array',
            'type' => 'required|in:header,footer,block' // Strict validation
        ]);

        // If saving a header or footer, demote the current one to 'block'
        if (in_array($validated['type'], ['header', 'footer'])) {
            Template::where('type', $validated['type'])
                ->update(['type' => 'block']);
        }

        $template = Template::create($validated);

        return response()->json($template, 201);
    }

    public function show(Template $template)
    {
        return response()->json($template);
    }

    public function update(Request $request, Template $template)
    {
        $validated = $request->validate([
            'title' => 'sometimes|string|max:255',
            'content' => 'nullable|array',
            'type' => 'sometimes|in:header,footer,block',
            'is_published' => 'boolean'
        ]);

        // If updating a template to be a header/footer, demote the OLD one
        if (isset($validated['type']) && in_array($validated['type'], ['header', 'footer'])) {
            // Ensure we don't demote the one we are currently updating
            Template::where('type', $validated['type'])
                ->where('id', '!=', $template->id)
                ->update(['type' => 'block']);
        }

        $template->update($validated);

        return response()->json($template);
    }

    // Remove a page
    public function destroy(Template $template)
    {
        $template->delete();
        return response()->json(['message' => 'Template moved to trash']);
    }
}
